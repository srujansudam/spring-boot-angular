package com.cg.ibs.rm.controller;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.model.Customer;
import com.cg.ibs.rm.service.CustomerService;

@RestController
@RequestMapping("/login")
@Scope("session")
@CrossOrigin
public class UserLogin {

	private BigInteger uci;
	@Autowired
	CustomerService customerService;

	public BigInteger getUci() {
		return uci;
	}

	public void setUci(BigInteger uci) {
		this.uci = uci;
	}

	@GetMapping("/{userId}")
	public ResponseEntity<Customer> getName(@PathVariable("userId") String userId) throws IBSExceptions {
		ResponseEntity<Customer> result;

		if (userId == null) {
			result = new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		} else {
			result = new ResponseEntity<>(customerService.getCustomer(userId), HttpStatus.OK);
			uci = customerService.getCustomer(userId).getUci();
		}

		return result;
	}

	@ExceptionHandler(IBSExceptions.class)
	public ResponseEntity<String> handleAdbException(IBSExceptions exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
